import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORS } from '../data/data';
import { useApp } from '../data/AppContext';

export default function DealCard({ deal, onPressCoupon, onPressDeal }) {
  const { savedDeals, toggleSave } = useApp();
  const saved = savedDeals.includes(deal.id);
  const isCoupon = deal.type === 'coupon';
  const stars = '★'.repeat(Math.floor(deal.rating)) + '☆'.repeat(5 - Math.floor(deal.rating));

  return (
    <View style={styles.card}>
      {deal.badge ? (
        <View style={[styles.badge, deal.badge === 'new' ? styles.badgeNew : styles.badgeHot]}>
          <Text style={styles.badgeText}>{deal.badge === 'new' ? '✨ NEW' : '🔥 HOT'}</Text>
        </View>
      ) : null}
      <View style={[styles.imgBox, { backgroundColor: isCoupon ? '#FEF0E8' : '#EBF2FC' }]}>
        <Text style={styles.emoji}>{deal.emoji}</Text>
      </View>
      <View style={styles.body}>
        <Text style={styles.storeName}>{deal.store}</Text>
        <Text style={styles.title} numberOfLines={2}>{deal.title}</Text>
        <Text style={styles.desc} numberOfLines={2}>{deal.desc}</Text>
        <View style={styles.metaRow}>
          <Text style={styles.disc}>{deal.disc}</Text>
          <View>
            <Text style={styles.stars}>{stars}</Text>
            <Text style={styles.exp}>Expires: {deal.exp}</Text>
          </View>
        </View>
        <View style={styles.actions}>
          {isCoupon ? (
            <TouchableOpacity style={[styles.btnPrimary, { backgroundColor: COLORS.orange }]} onPress={() => onPressCoupon && onPressCoupon(deal)}>
              <Text style={styles.btnPrimaryText}>🎟️ Show Coupon</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity style={[styles.btnPrimary, { backgroundColor: COLORS.green }]} onPress={() => onPressDeal && onPressDeal(deal)}>
              <Text style={styles.btnPrimaryText}>⚡ Get This Deal</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            style={[styles.btnSecondary, saved && { borderColor: COLORS.orange, backgroundColor: COLORS.orangeLt }]}
            onPress={() => toggleSave(deal.id)}>
            <Text style={[styles.btnSecText, saved && { color: COLORS.orange }]}>{saved ? '🔖 Saved' : '🔖 Save'}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: COLORS.white, borderRadius: 16, marginBottom: 14, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.07, shadowRadius: 8, elevation: 3, overflow: 'hidden', position: 'relative' },
  badge: { position: 'absolute', top: 10, left: 10, zIndex: 10, paddingHorizontal: 9, paddingVertical: 3, borderRadius: 20 },
  badgeNew: { backgroundColor: COLORS.green },
  badgeHot: { backgroundColor: COLORS.coral },
  badgeText: { color: '#fff', fontSize: 10, fontWeight: '700' },
  imgBox: { height: 110, alignItems: 'center', justifyContent: 'center' },
  emoji: { fontSize: 44 },
  body: { padding: 14 },
  storeName: { fontSize: 11, fontWeight: '700', color: COLORS.orange, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 4 },
  title: { fontSize: 14, fontWeight: '700', color: COLORS.text, marginBottom: 5, lineHeight: 20 },
  desc: { fontSize: 12, color: COLORS.text2, marginBottom: 10, lineHeight: 17 },
  metaRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  disc: { fontSize: 20, fontWeight: '800', color: COLORS.orange },
  stars: { fontSize: 12, color: COLORS.orange, letterSpacing: 1 },
  exp: { fontSize: 10, color: COLORS.muted, marginTop: 1 },
  actions: { flexDirection: 'row', gap: 8 },
  btnPrimary: { flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  btnPrimaryText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  btnSecondary: { paddingHorizontal: 14, paddingVertical: 10, borderRadius: 10, borderWidth: 1.5, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  btnSecText: { fontSize: 13, fontWeight: '600', color: COLORS.text2 },
});
