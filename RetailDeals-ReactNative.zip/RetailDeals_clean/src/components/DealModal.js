import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Modal, ScrollView, Linking } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { COLORS } from '../data/data';

export default function DealModal({ deal, visible, onClose }) {
  const [revealed, setRevealed] = useState(false);
  if (!deal) return null;
  const isCoupon = deal.type === 'coupon';

  const handleReveal = async () => {
    setRevealed(true);
    await Clipboard.setStringAsync(deal.code);
    setTimeout(() => {
      onClose();
      setRevealed(false);
      Linking.openURL(deal.href);
    }, 1600);
  };

  const handleGetDeal = () => {
    onClose();
    Linking.openURL(deal.href);
  };

  const handleGoStore = () => {
    onClose();
    Linking.openURL(deal.href);
  };

  const stars = '★'.repeat(Math.floor(deal.rating)) + '☆'.repeat(5 - Math.floor(deal.rating));

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={onClose}>
        <TouchableOpacity style={styles.sheet} activeOpacity={1} onPress={() => {}}>
          <View style={styles.grip} />
          <ScrollView showsVerticalScrollIndicator={false}>
            <View style={styles.inner}>
              <View style={[styles.typeBadge, { backgroundColor: isCoupon ? COLORS.orangeLt : COLORS.greenLt }]}>
                <Text style={[styles.typeBadgeText, { color: isCoupon ? COLORS.orange : COLORS.green }]}>
                  {isCoupon ? '🎟️ Coupon Code' : '⚡ Deal'}
                </Text>
              </View>
              <Text style={styles.title}>{deal.title}</Text>
              <Text style={styles.desc}>{deal.desc}</Text>
              <View style={styles.tagRow}>
                <View style={styles.tag}><Text style={styles.tagText}>🏷️ {deal.disc}</Text></View>
                <View style={styles.tag}><Text style={styles.tagText}>📅 {deal.exp}</Text></View>
                <View style={styles.tag}><Text style={styles.tagText}>⭐ {deal.rating}</Text></View>
              </View>

              {isCoupon ? (
                <>
                  <View style={styles.couponBox}>
                    <Text style={styles.couponLabel}>YOUR COUPON CODE</Text>
                    <Text style={[styles.couponCode, revealed && styles.couponRevealed]}>
                      {deal.code}
                    </Text>
                    {revealed && <Text style={styles.copiedHint}>✅ Copied to clipboard!</Text>}
                  </View>
                  <TouchableOpacity style={styles.btnOrange} onPress={handleReveal} disabled={revealed}>
                    <Text style={styles.btnText}>{revealed ? '✅ Code Copied! Opening Store…' : '🎟️ Reveal & Copy Code'}</Text>
                  </TouchableOpacity>
                </>
              ) : (
                <TouchableOpacity style={styles.btnGreen} onPress={handleGetDeal}>
                  <Text style={styles.btnText}>⚡ Get This Deal – Open {deal.store}</Text>
                </TouchableOpacity>
              )}

              <TouchableOpacity style={styles.btnStore} onPress={handleGoStore}>
                <Text style={styles.btnStoreText}>🏪 Go to {deal.store}</Text>
              </TouchableOpacity>
              <Text style={styles.note}>
                {isCoupon
                  ? 'Tapping "Reveal & Copy" copies the code and opens the store automatically.'
                  : `You will be redirected to ${deal.store}'s website to claim this deal.`}
              </Text>
            </View>
          </ScrollView>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(26,26,36,0.5)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: COLORS.white, borderTopLeftRadius: 24, borderTopRightRadius: 24, maxHeight: '88%' },
  grip: { width: 36, height: 4, backgroundColor: COLORS.border, borderRadius: 2, alignSelf: 'center', marginTop: 12 },
  inner: { padding: 22, paddingBottom: 40 },
  typeBadge: { alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20, marginBottom: 10 },
  typeBadgeText: { fontSize: 12, fontWeight: '700' },
  title: { fontSize: 20, fontWeight: '800', color: COLORS.text, marginBottom: 8, lineHeight: 26 },
  desc: { fontSize: 14, color: COLORS.text2, lineHeight: 21, marginBottom: 16 },
  tagRow: { flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginBottom: 20 },
  tag: { backgroundColor: COLORS.surface2, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20 },
  tagText: { fontSize: 12, color: COLORS.text2 },
  couponBox: { backgroundColor: '#FFF8F3', borderWidth: 2, borderColor: COLORS.orange, borderStyle: 'dashed', borderRadius: 14, padding: 20, alignItems: 'center', marginBottom: 16 },
  couponLabel: { fontSize: 11, color: COLORS.muted, letterSpacing: 1.2, marginBottom: 8, textTransform: 'uppercase' },
  couponCode: { fontSize: 28, fontWeight: '800', color: COLORS.orange, letterSpacing: 5, opacity: 0.15 },
  couponRevealed: { opacity: 1 },
  copiedHint: { marginTop: 8, fontSize: 13, color: COLORS.green, fontWeight: '600' },
  btnOrange: { backgroundColor: COLORS.orange, borderRadius: 12, paddingVertical: 15, alignItems: 'center', marginBottom: 10, shadowColor: COLORS.orange, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.28, shadowRadius: 8, elevation: 4 },
  btnGreen:  { backgroundColor: COLORS.green,  borderRadius: 12, paddingVertical: 15, alignItems: 'center', marginBottom: 10, shadowColor: COLORS.green,  shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.28, shadowRadius: 8, elevation: 4 },
  btnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  btnStore: { borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 12, paddingVertical: 13, alignItems: 'center', marginBottom: 10 },
  btnStoreText: { fontSize: 14, fontWeight: '600', color: COLORS.text2 },
  note: { textAlign: 'center', fontSize: 11, color: COLORS.muted, lineHeight: 16, marginTop: 4 },
});
