import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { COLORS } from '../data/data';
import { useApp } from '../data/AppContext';

import HomeScreen          from '../screens/HomeScreen';
import CategoriesScreen    from '../screens/CategoriesScreen';
import StoresScreen        from '../screens/StoresScreen';
import StoreDetailScreen   from '../screens/StoreDetailScreen';
import ReviewsScreen       from '../screens/ReviewsScreen';
import BlogScreen          from '../screens/BlogScreen';
import ProfileScreen       from '../screens/ProfileScreen';
import NotificationsScreen from '../screens/NotificationsScreen';

const Tab   = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

function StoresStack() {
  return (
    <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: COLORS.white }, headerTintColor: COLORS.text, headerShadowVisible: false }}>
      <Stack.Screen name="StoresList"   component={StoresScreen}      options={{ title: 'Stores' }} />
      <Stack.Screen name="StoreDetail"  component={StoreDetailScreen}  options={({ route }) => ({ title: '' })} />
    </Stack.Navigator>
  );
}

function TabIcon({ emoji, label, focused }) {
  return (
    <View style={[tabStyles.wrap, focused && tabStyles.wrapActive]}>
      <Text style={tabStyles.emoji}>{emoji}</Text>
      <Text style={[tabStyles.label, focused && tabStyles.labelActive]}>{label}</Text>
    </View>
  );
}

const tabStyles = StyleSheet.create({
  wrap: { alignItems: 'center', paddingTop: 6, paddingHorizontal: 10, paddingBottom: 2, borderRadius: 12 },
  wrapActive: { backgroundColor: COLORS.orangeLt },
  emoji: { fontSize: 20, lineHeight: 24 },
  label: { fontSize: 10, fontWeight: '600', color: COLORS.muted, marginTop: 2 },
  labelActive: { color: COLORS.orange },
});

export default function AppNavigator({ onLogout }) {
  const { unreadCount } = useApp();

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: COLORS.white },
          headerTintColor: COLORS.text,
          headerShadowVisible: false,
          tabBarStyle: {
            backgroundColor: COLORS.white,
            borderTopColor: COLORS.border,
            borderTopWidth: 1,
            height: 72,
            paddingBottom: 8,
            paddingTop: 4,
          },
          tabBarShowLabel: false,
        }}
      >
        <Tab.Screen
          name="Home"
          component={HomeScreen}
          options={{
            title: '🏷️ RetailDeals',
            headerRight: () => <NotifHeaderButton />,
            headerRightContainerStyle: { paddingRight: 16 },
            tabBarIcon: ({ focused }) => <TabIcon emoji="🏠" label="Home" focused={focused} />,
          }}
        />
        <Tab.Screen
          name="Categories"
          component={CategoriesScreen}
          options={{
            title: 'Categories',
            tabBarIcon: ({ focused }) => <TabIcon emoji="📂" label="Categories" focused={focused} />,
          }}
        />
        <Tab.Screen
          name="Stores"
          component={StoresStack}
          options={{
            headerShown: false,
            tabBarIcon: ({ focused }) => <TabIcon emoji="🏪" label="Stores" focused={focused} />,
          }}
        />
        <Tab.Screen
          name="Reviews"
          component={ReviewsScreen}
          options={{
            title: 'Reviews',
            tabBarIcon: ({ focused }) => <TabIcon emoji="⭐" label="Reviews" focused={focused} />,
          }}
        />
        <Tab.Screen
          name="Blog"
          component={BlogScreen}
          options={{
            title: 'Blog',
            tabBarIcon: ({ focused }) => <TabIcon emoji="📰" label="Blog" focused={focused} />,
          }}
        />
        <Tab.Screen
          name="Profile"
          options={{
            title: 'My Profile',
            tabBarIcon: ({ focused }) => <TabIcon emoji="👤" label="Profile" focused={focused} />,
          }}
        >
          {() => <ProfileScreen onLogout={onLogout} />}
        </Tab.Screen>
        <Tab.Screen
          name="Notifications"
          component={NotificationsScreen}
          options={{
            title: 'Notifications',
            tabBarIcon: ({ focused }) => <NotifTabIcon focused={focused} />,
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

function NotifHeaderButton() {
  const { unreadCount } = useApp();
  return (
    <View style={{ position: 'relative' }}>
      <Text style={{ fontSize: 22 }}>🔔</Text>
      {unreadCount > 0 && (
        <View style={{ position: 'absolute', top: -2, right: -2, width: 10, height: 10, borderRadius: 5, backgroundColor: COLORS.coral, borderWidth: 1.5, borderColor: COLORS.white }} />
      )}
    </View>
  );
}

function NotifTabIcon({ focused }) {
  const { unreadCount } = useApp();
  return (
    <View style={{ position: 'relative', alignItems: 'center' }}>
      <TabIcon emoji="🔔" label="Alerts" focused={focused} />
      {unreadCount > 0 && (
        <View style={{ position: 'absolute', top: 4, right: 4, backgroundColor: COLORS.coral, borderRadius: 8, minWidth: 16, height: 16, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: COLORS.white }}>
          <Text style={{ color: '#fff', fontSize: 9, fontWeight: '800' }}>{unreadCount}</Text>
        </View>
      )}
    </View>
  );
}
