import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, FlatList } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { COLORS, CATEGORIES, STORES, COUNTRIES } from '../data/data';
import { useApp } from '../data/AppContext';
import DealCard from '../components/DealCard';
import DealModal from '../components/DealModal';

export default function HomeScreen({ navigation }) {
  const { country, countryDeals } = useApp();
  const [search, setSearch] = useState('');
  const [activeCat, setActiveCat] = useState('All');
  const [typeFilter, setTypeFilter] = useState('All');
  const [modalDeal, setModalDeal] = useState(null);

  const c = COUNTRIES.find(x => x.code === country) || COUNTRIES[0];
  const cats = ['All', ...CATEGORIES.map(c => c.name)];

  let deals = countryDeals();
  if (activeCat !== 'All') deals = deals.filter(d => d.cat === activeCat);
  if (typeFilter === 'Deals')   deals = deals.filter(d => d.type === 'deal');
  if (typeFilter === 'Coupons') deals = deals.filter(d => d.type === 'coupon');
  if (search) deals = deals.filter(d => d.title.toLowerCase().includes(search.toLowerCase()) || d.store.toLowerCase().includes(search.toLowerCase()));

  const topStores = STORES.filter(s => s.countries.includes(country)).slice(0, 6);

  return (
    <ScrollView style={styles.wrap} showsVerticalScrollIndicator={false}>
      {/* HERO BANNER */}
      <LinearGradient colors={['#F26522', '#E8543A', '#3B7DD8']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.hero}>
        <View style={styles.heroPattern} />
        <View style={styles.eyebrow}>
          <Text style={styles.eyebrowText}>🔥 {c.flag} {c.name} · New Deals Daily</Text>
        </View>
        <Text style={styles.heroH1}>Find the Best{'\n'}<Text style={styles.heroItalic}>Coupons & Deals</Text></Text>
        <Text style={styles.heroSub}>Verified codes from top stores. Save big with one tap.</Text>
        <View style={styles.searchBar}>
          <Text style={styles.searchIcon}>🔍</Text>
          <TextInput
            style={styles.searchInput}
            placeholder="Search stores, brands…"
            placeholderTextColor={COLORS.muted2}
            value={search}
            onChangeText={setSearch}
          />
        </View>
        {/* Type filter pills on hero */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.heroFilters}>
          {['All','Deals','Coupons'].map(f => (
            <TouchableOpacity key={f} style={[styles.heroFilter, typeFilter === f && styles.heroFilterActive]} onPress={() => setTypeFilter(f)}>
              <Text style={[styles.heroFilterText, typeFilter === f && styles.heroFilterTextActive]}>
                {f === 'All' ? '🔥 All' : f === 'Deals' ? '⚡ Deals' : '🎟️ Coupons'}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </LinearGradient>

      {/* STATS */}
      <View style={styles.statsBar}>
        {[{ n: c.deals + '+', l: 'Active Deals' }, { n: c.stores + '+', l: 'Stores' }, { n: '$4.8M', l: 'Saved' }, { n: '98%', l: 'Verified' }].map(s => (
          <View key={s.l} style={styles.statItem}>
            <Text style={styles.statN}>{s.n}</Text>
            <Text style={styles.statL}>{s.l}</Text>
          </View>
        ))}
      </View>

      {/* CATEGORY PILLS */}
      <View style={styles.section}>
        <View style={styles.secHead}>
          <Text style={styles.secTitle}>Featured Deals</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Categories')}><Text style={styles.seeAll}>View All →</Text></TouchableOpacity>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.pillRow}>
          {cats.map(cat => (
            <TouchableOpacity key={cat} style={[styles.pill, activeCat === cat && styles.pillActive]} onPress={() => setActiveCat(cat)}>
              <Text style={[styles.pillText, activeCat === cat && styles.pillTextActive]}>
                {cat === 'All' ? '🔥 All' : (CATEGORIES.find(c => c.name === cat)?.icon || '') + ' ' + cat}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        {deals.length === 0
          ? <Text style={styles.empty}>No deals found. Try a different filter.</Text>
          : deals.map(d => <DealCard key={d.id} deal={d} onPressCoupon={setModalDeal} onPressDeal={setModalDeal} />)
        }
      </View>

      {/* TOP STORES */}
      <View style={[styles.section, styles.storeSection]}>
        <View style={styles.secHead}>
          <Text style={styles.secTitle}>Top Stores</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Stores')}><Text style={styles.seeAll}>All Stores →</Text></TouchableOpacity>
        </View>
        <View style={styles.storeGrid}>
          {topStores.map(s => (
            <TouchableOpacity key={s.id} style={styles.storeCard} onPress={() => navigation.navigate('StoreDetail', { storeId: s.id })}>
              <Text style={styles.storeLogo}>{s.logo}</Text>
              <Text style={styles.storeName}>{s.name}</Text>
              <Text style={styles.storeCount}>{s.deals} deals</Text>
              <View style={styles.storeCatTag}><Text style={styles.storeCatText}>{s.cat}</Text></View>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <DealModal deal={modalDeal} visible={!!modalDeal} onClose={() => setModalDeal(null)} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  hero: { paddingTop: 56, paddingHorizontal: 20, paddingBottom: 24 },
  heroPattern: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, opacity: 0.08 },
  eyebrow: { backgroundColor: 'rgba(255,255,255,0.18)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.3)', alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20, marginBottom: 12 },
  eyebrowText: { color: '#fff', fontSize: 11, fontWeight: '600' },
  heroH1: { fontSize: 28, fontWeight: '800', color: '#fff', lineHeight: 34, marginBottom: 8 },
  heroItalic: { fontStyle: 'italic', color: 'rgba(255,255,255,0.92)' },
  heroSub: { color: 'rgba(255,255,255,0.85)', fontSize: 14, marginBottom: 16, lineHeight: 20 },
  searchBar: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.white, borderRadius: 50, paddingHorizontal: 16, paddingVertical: 11, gap: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 8, elevation: 5 },
  searchIcon: { fontSize: 16 },
  searchInput: { flex: 1, fontSize: 14, color: COLORS.text },
  heroFilters: { paddingTop: 14, gap: 8, paddingRight: 8 },
  heroFilter: { backgroundColor: 'rgba(255,255,255,0.18)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.3)', paddingHorizontal: 16, paddingVertical: 7, borderRadius: 20 },
  heroFilterActive: { backgroundColor: COLORS.white },
  heroFilterText: { color: '#fff', fontSize: 13, fontWeight: '600' },
  heroFilterTextActive: { color: COLORS.orange },
  statsBar: { flexDirection: 'row', backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  statItem: { flex: 1, padding: 12, alignItems: 'center', borderRightWidth: 1, borderRightColor: COLORS.border },
  statN: { fontSize: 16, fontWeight: '800', color: COLORS.orange },
  statL: { fontSize: 9, color: COLORS.muted, textTransform: 'uppercase', letterSpacing: 0.4, marginTop: 2 },
  section: { padding: 18 },
  storeSection: { backgroundColor: COLORS.white, margin: 14, borderRadius: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  secHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  secTitle: { fontSize: 18, fontWeight: '800', color: COLORS.text },
  seeAll: { fontSize: 13, color: COLORS.orange, fontWeight: '600' },
  pillRow: { gap: 8, paddingBottom: 16 },
  pill: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1.5, borderColor: COLORS.border, backgroundColor: COLORS.white },
  pillActive: { backgroundColor: COLORS.orange, borderColor: COLORS.orange },
  pillText: { fontSize: 13, fontWeight: '500', color: COLORS.text2 },
  pillTextActive: { color: '#fff', fontWeight: '700' },
  empty: { textAlign: 'center', color: COLORS.muted, fontSize: 14, paddingVertical: 24 },
  storeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  storeCard: { width: '30%', backgroundColor: COLORS.surface2, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 12, padding: 12, alignItems: 'center' },
  storeLogo: { fontSize: 28, marginBottom: 6 },
  storeName: { fontSize: 12, fontWeight: '700', color: COLORS.text, textAlign: 'center' },
  storeCount: { fontSize: 10, color: COLORS.muted, marginTop: 2 },
  storeCatTag: { backgroundColor: COLORS.orangeLt, paddingHorizontal: 7, paddingVertical: 2, borderRadius: 20, marginTop: 5 },
  storeCatText: { fontSize: 9, color: COLORS.orange, fontWeight: '700' },
});
