import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORS, STORES, COUNTRIES } from '../data/data';
import { useApp } from '../data/AppContext';

export default function StoresScreen({ navigation }) {
  const { country } = useApp();
  const [catFilter, setCatFilter] = useState('All');
  const c = COUNTRIES.find(x => x.code === country);
  const stores = STORES.filter(s => s.countries.includes(country));
  const cats = ['All', ...new Set(stores.map(s => s.cat))];
  const filtered = catFilter === 'All' ? stores : stores.filter(s => s.cat === catFilter);

  return (
    <ScrollView style={styles.wrap} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.h1}>All Stores</Text>
        <Text style={styles.sub}>Showing {stores.length} stores for {c?.flag} {c?.name}</Text>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.catRow}>
        {cats.map(cat => (
          <TouchableOpacity key={cat} style={[styles.pill, catFilter === cat && styles.pillActive]} onPress={() => setCatFilter(cat)}>
            <Text style={[styles.pillText, catFilter === cat && styles.pillTextActive]}>{cat}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <View style={styles.grid}>
        {filtered.map(s => (
          <TouchableOpacity key={s.id} style={styles.card} onPress={() => navigation.navigate('StoreDetail', { storeId: s.id })}>
            <Text style={styles.logo}>{s.logo}</Text>
            <Text style={styles.name}>{s.name}</Text>
            <Text style={styles.count}>{s.deals} deals</Text>
            <View style={styles.catTag}><Text style={styles.catTagText}>{s.cat}</Text></View>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  header: { padding: 20, paddingTop: 24 },
  h1: { fontSize: 24, fontWeight: '800', color: COLORS.text, marginBottom: 4 },
  sub: { fontSize: 13, color: COLORS.text2 },
  catRow: { paddingHorizontal: 16, paddingBottom: 16, gap: 8 },
  pill: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1.5, borderColor: COLORS.border, backgroundColor: COLORS.white },
  pillActive: { backgroundColor: COLORS.orange, borderColor: COLORS.orange },
  pillText: { fontSize: 13, fontWeight: '500', color: COLORS.text2 },
  pillTextActive: { color: '#fff', fontWeight: '700' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, paddingHorizontal: 16, paddingBottom: 30 },
  card: { width: '30%', backgroundColor: COLORS.white, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 14, padding: 14, alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  logo: { fontSize: 32, marginBottom: 8 },
  name: { fontSize: 12, fontWeight: '700', color: COLORS.text, textAlign: 'center', marginBottom: 3 },
  count: { fontSize: 10, color: COLORS.muted },
  catTag: { backgroundColor: COLORS.orangeLt, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 20, marginTop: 6 },
  catTagText: { fontSize: 9, color: COLORS.orange, fontWeight: '700' },
});
