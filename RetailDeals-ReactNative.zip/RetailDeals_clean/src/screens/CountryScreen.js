import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { COLORS, COUNTRIES } from '../data/data';
import { useApp } from '../data/AppContext';

export default function CountryScreen({ onContinue }) {
  const { country, setCountry } = useApp();
  return (
    <ScrollView style={styles.wrap} contentContainerStyle={{ padding: 24, paddingTop: 60 }}>
      <Text style={styles.h1}>🌍 Choose Your Country</Text>
      <Text style={styles.sub}>We'll personalise all deals, stores and coupons for your location.</Text>
      <View style={styles.grid}>
        {COUNTRIES.map(c => (
          <TouchableOpacity key={c.code} style={[styles.card, country === c.code && styles.cardSel]} onPress={() => setCountry(c.code)}>
            <Text style={styles.flag}>{c.flag}</Text>
            <Text style={styles.name}>{c.name}</Text>
            <Text style={styles.count}>{c.deals}+ deals</Text>
          </TouchableOpacity>
        ))}
      </View>
      <TouchableOpacity style={styles.btn} onPress={onContinue}>
        <Text style={styles.btnText}>Continue → Show My Deals</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  h1: { fontSize: 26, fontWeight: '800', color: COLORS.text, marginBottom: 8 },
  sub: { fontSize: 14, color: COLORS.text2, marginBottom: 28, lineHeight: 20 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 28 },
  card: { width: '47%', backgroundColor: COLORS.white, borderWidth: 2, borderColor: COLORS.border, borderRadius: 14, padding: 16, alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  cardSel: { borderColor: COLORS.orange, backgroundColor: COLORS.orangeLt },
  flag: { fontSize: 32, marginBottom: 8 },
  name: { fontSize: 13, fontWeight: '700', color: COLORS.text, textAlign: 'center' },
  count: { fontSize: 11, color: COLORS.muted, marginTop: 3 },
  btn: { backgroundColor: COLORS.orange, borderRadius: 12, paddingVertical: 15, alignItems: 'center', shadowColor: COLORS.orange, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.28, shadowRadius: 8, elevation: 4 },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
