import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORS } from '../data/data';
import { useApp } from '../data/AppContext';

export default function NotificationsScreen() {
  const { notifs, markRead, markAllRead, unreadCount } = useApp();

  return (
    <ScrollView style={styles.wrap} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <View style={styles.headerRow}>
          <Text style={styles.h1}>Notifications</Text>
          {unreadCount > 0 && (
            <TouchableOpacity style={styles.markAllBtn} onPress={markAllRead}>
              <Text style={styles.markAllText}>Mark all read</Text>
            </TouchableOpacity>
          )}
        </View>
        {unreadCount > 0
          ? <Text style={styles.sub}>{unreadCount} unread notification{unreadCount > 1 ? 's' : ''}</Text>
          : <Text style={styles.sub}>You're all caught up!</Text>}
      </View>

      <View style={styles.list}>
        {notifs.map(n => (
          <TouchableOpacity
            key={n.id}
            style={[styles.item, n.unread && styles.itemUnread]}
            onPress={() => markRead(n.id)}
            activeOpacity={0.7}
          >
            <View style={[styles.iconWrap, { backgroundColor: n.unread ? COLORS.orangeLt : COLORS.surface2 }]}>
              <Text style={styles.icon}>{n.icon}</Text>
            </View>
            <View style={styles.body}>
              <View style={styles.bodyTop}>
                <Text style={styles.title}>{n.title}</Text>
                {n.unread && <View style={styles.dot} />}
              </View>
              <Text style={styles.text}>{n.text}</Text>
              <Text style={styles.time}>{n.time}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  header: { padding: 20, paddingTop: 24 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  h1: { fontSize: 24, fontWeight: '800', color: COLORS.text },
  markAllBtn: { backgroundColor: COLORS.blueLt, paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20 },
  markAllText: { fontSize: 12, fontWeight: '600', color: COLORS.blue },
  sub: { fontSize: 13, color: COLORS.text2 },
  list: { paddingHorizontal: 16, paddingBottom: 30 },
  item: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 12,
    backgroundColor: COLORS.white, borderRadius: 14, padding: 14,
    marginBottom: 10,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05, shadowRadius: 4, elevation: 2,
  },
  itemUnread: { borderLeftWidth: 3, borderLeftColor: COLORS.orange },
  iconWrap: { width: 42, height: 42, borderRadius: 12, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  icon: { fontSize: 20 },
  body: { flex: 1 },
  bodyTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 3 },
  title: { fontSize: 14, fontWeight: '700', color: COLORS.text, flex: 1 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: COLORS.coral, marginLeft: 8 },
  text: { fontSize: 13, color: COLORS.text2, lineHeight: 18, marginBottom: 5 },
  time: { fontSize: 11, color: COLORS.muted },
});
