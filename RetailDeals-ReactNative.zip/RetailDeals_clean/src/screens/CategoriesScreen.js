import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORS, CATEGORIES } from '../data/data';
import { useApp } from '../data/AppContext';
import DealCard from '../components/DealCard';
import DealModal from '../components/DealModal';

export default function CategoriesScreen({ navigation }) {
  const { countryDeals } = useApp();
  const [selected, setSelected] = useState(null);
  const [modalDeal, setModalDeal] = useState(null);

  const deals = selected ? countryDeals().filter(d => d.cat === selected) : [];

  return (
    <ScrollView style={styles.wrap} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.h1}>Browse Categories</Text>
        <Text style={styles.sub}>Shop smarter across every category</Text>
      </View>
      <View style={styles.grid}>
        {CATEGORIES.map(cat => {
          const count = countryDeals().filter(d => d.cat === cat.name).length;
          return (
            <TouchableOpacity
              key={cat.name}
              style={[styles.card, selected === cat.name && styles.cardSel]}
              onPress={() => setSelected(selected === cat.name ? null : cat.name)}>
              <View style={[styles.iconBox, { backgroundColor: cat.bg }]}>
                <Text style={styles.icon}>{cat.icon}</Text>
              </View>
              <Text style={styles.catName}>{cat.name}</Text>
              <Text style={styles.catCount}>{count} deals</Text>
              <View style={styles.tagsRow}>
                {cat.tags.slice(0, 2).map(t => <View key={t} style={styles.tag}><Text style={styles.tagText}>{t}</Text></View>)}
              </View>
            </TouchableOpacity>
          );
        })}
      </View>
      {selected && (
        <View style={styles.dealsSection}>
          <View style={styles.dealsSectionHead}>
            <Text style={styles.dealsSectionTitle}>
              {CATEGORIES.find(c => c.name === selected)?.icon} {selected} Deals
            </Text>
            <TouchableOpacity onPress={() => setSelected(null)}><Text style={styles.closeBtn}>✕ Close</Text></TouchableOpacity>
          </View>
          {deals.length === 0
            ? <Text style={styles.empty}>No deals in this category for your country.</Text>
            : deals.map(d => <DealCard key={d.id} deal={d} onPressCoupon={setModalDeal} onPressDeal={setModalDeal} />)
          }
        </View>
      )}
      <DealModal deal={modalDeal} visible={!!modalDeal} onClose={() => setModalDeal(null)} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  header: { padding: 20, paddingTop: 24 },
  h1: { fontSize: 24, fontWeight: '800', color: COLORS.text, marginBottom: 4 },
  sub: { fontSize: 14, color: COLORS.text2 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, paddingHorizontal: 16, paddingBottom: 8 },
  card: { width: '47%', backgroundColor: COLORS.white, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 14, padding: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  cardSel: { borderColor: COLORS.orange, backgroundColor: COLORS.orangeLt },
  iconBox: { width: 48, height: 48, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  icon: { fontSize: 24 },
  catName: { fontSize: 14, fontWeight: '700', color: COLORS.text, marginBottom: 3 },
  catCount: { fontSize: 12, color: COLORS.muted, marginBottom: 8 },
  tagsRow: { flexDirection: 'row', gap: 5, flexWrap: 'wrap' },
  tag: { backgroundColor: COLORS.surface2, paddingHorizontal: 7, paddingVertical: 2, borderRadius: 20 },
  tagText: { fontSize: 10, color: COLORS.text2 },
  dealsSection: { padding: 16 },
  dealsSectionHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  dealsSectionTitle: { fontSize: 17, fontWeight: '800', color: COLORS.text },
  closeBtn: { fontSize: 13, color: COLORS.muted, fontWeight: '600' },
  empty: { textAlign: 'center', color: COLORS.muted, padding: 24, fontSize: 14 },
});
