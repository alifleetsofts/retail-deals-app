import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { COLORS, COUNTRIES } from '../data/data';
import { useApp } from '../data/AppContext';

export default function AuthScreen({ onAuth }) {
  const [mode, setMode] = useState('login'); // login | register
  const [form, setForm] = useState({ email: '', password: '', firstName: '', lastName: '', country: 'US' });
  const { login } = useApp();

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleLogin = () => {
    if (!form.email) return;
    const name = form.email.split('@')[0];
    login({ name: name.charAt(0).toUpperCase() + name.slice(1), email: form.email, country: form.country, init: form.email[0].toUpperCase() });
    onAuth();
  };

  const handleRegister = () => {
    if (!form.firstName || !form.email) return;
    login({ name: form.firstName + (form.lastName ? ' ' + form.lastName : ''), email: form.email, country: form.country, init: form.firstName[0].toUpperCase() });
    onAuth();
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <LinearGradient colors={['#F26522', '#D4521A']} style={styles.header}>
        <Text style={styles.logo}>🏷️ RetailDeals</Text>
        <Text style={styles.tagline}>Verified coupons & deals from top stores tailored to your country</Text>
        <View style={styles.pills}>
          {['✅ Verified', '🌍 Multi-Country', '🔔 Alerts', '💸 Big Savings'].map(p => (
            <View key={p} style={styles.pill}><Text style={styles.pillText}>{p}</Text></View>
          ))}
        </View>
      </LinearGradient>
      <ScrollView style={styles.form} contentContainerStyle={{ padding: 24 }} keyboardShouldPersistTaps="handled">
        <View style={styles.tabs}>
          <TouchableOpacity style={[styles.tab, mode === 'login' && styles.tabActive]} onPress={() => setMode('login')}>
            <Text style={[styles.tabText, mode === 'login' && styles.tabTextActive]}>Sign In</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.tab, mode === 'register' && styles.tabActive]} onPress={() => setMode('register')}>
            <Text style={[styles.tabText, mode === 'register' && styles.tabTextActive]}>Create Account</Text>
          </TouchableOpacity>
        </View>

        {mode === 'register' && (
          <View style={styles.row}>
            <View style={{ flex: 1, marginRight: 8 }}>
              <Text style={styles.label}>First Name</Text>
              <TextInput style={styles.input} placeholder="Jane" placeholderTextColor={COLORS.muted2} value={form.firstName} onChangeText={v => set('firstName', v)} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Last Name</Text>
              <TextInput style={styles.input} placeholder="Smith" placeholderTextColor={COLORS.muted2} value={form.lastName} onChangeText={v => set('lastName', v)} />
            </View>
          </View>
        )}

        <Text style={styles.label}>Email Address</Text>
        <TextInput style={styles.input} placeholder="you@example.com" placeholderTextColor={COLORS.muted2} keyboardType="email-address" autoCapitalize="none" value={form.email} onChangeText={v => set('email', v)} />

        <Text style={styles.label}>Password</Text>
        <TextInput style={styles.input} placeholder="••••••••" placeholderTextColor={COLORS.muted2} secureTextEntry value={form.password} onChangeText={v => set('password', v)} />

        {mode === 'register' && (
          <>
            <Text style={styles.label}>Your Country</Text>
            <View style={styles.countryGrid}>
              {COUNTRIES.map(c => (
                <TouchableOpacity
                  key={c.code}
                  style={[styles.countryChip, form.country === c.code && styles.countryChipSel]}
                  onPress={() => set('country', c.code)}>
                  <Text style={styles.countryFlag}>{c.flag}</Text>
                  <Text style={[styles.countryCode, form.country === c.code && { color: COLORS.orange }]}>{c.code}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </>
        )}

        <TouchableOpacity style={styles.btnSubmit} onPress={mode === 'login' ? handleLogin : handleRegister}>
          <Text style={styles.btnSubmitText}>{mode === 'login' ? 'Sign In →' : 'Create Account →'}</Text>
        </TouchableOpacity>

        <View style={styles.dividerRow}>
          <View style={styles.dividerLine} /><Text style={styles.dividerText}>or</Text><View style={styles.dividerLine} />
        </View>
        <View style={styles.socialRow}>
          {['🔵 Google', '🔷 Facebook'].map(s => (
            <TouchableOpacity key={s} style={styles.socialBtn} onPress={() => { login({ name: s.split(' ')[1]+' User', email: 'user@'+s.split(' ')[1].toLowerCase()+'.com', country: 'US', init: s.split(' ')[1][0] }); onAuth(); }}>
              <Text style={styles.socialText}>{s}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  header: { paddingTop: 56, paddingHorizontal: 24, paddingBottom: 28 },
  logo: { fontSize: 26, fontWeight: '800', color: '#fff', marginBottom: 8 },
  tagline: { fontSize: 13, color: 'rgba(255,255,255,0.88)', lineHeight: 19, marginBottom: 14 },
  pills: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  pill: { backgroundColor: 'rgba(255,255,255,0.18)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.28)', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 20 },
  pillText: { color: '#fff', fontSize: 12, fontWeight: '500' },
  form: { flex: 1, backgroundColor: COLORS.white },
  tabs: { flexDirection: 'row', backgroundColor: COLORS.surface2, borderRadius: 10, padding: 3, marginBottom: 20 },
  tab: { flex: 1, paddingVertical: 9, borderRadius: 8, alignItems: 'center' },
  tabActive: { backgroundColor: COLORS.white, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.08, shadowRadius: 3, elevation: 2 },
  tabText: { fontSize: 14, fontWeight: '600', color: COLORS.muted },
  tabTextActive: { color: COLORS.orange },
  row: { flexDirection: 'row', marginBottom: 0 },
  label: { fontSize: 11, fontWeight: '700', color: COLORS.muted, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6, marginTop: 14 },
  input: { backgroundColor: COLORS.surface2, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, color: COLORS.text },
  countryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 },
  countryChip: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10, borderWidth: 1.5, borderColor: COLORS.border, backgroundColor: COLORS.white },
  countryChipSel: { borderColor: COLORS.orange, backgroundColor: COLORS.orangeLt },
  countryFlag: { fontSize: 18 },
  countryCode: { fontSize: 12, fontWeight: '700', color: COLORS.text2 },
  btnSubmit: { backgroundColor: COLORS.orange, borderRadius: 12, paddingVertical: 15, alignItems: 'center', marginTop: 20, shadowColor: COLORS.orange, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.28, shadowRadius: 8, elevation: 4 },
  btnSubmitText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  dividerRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginVertical: 16 },
  dividerLine: { flex: 1, height: 1, backgroundColor: COLORS.border },
  dividerText: { fontSize: 12, color: COLORS.muted },
  socialRow: { flexDirection: 'row', gap: 10 },
  socialBtn: { flex: 1, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 10, paddingVertical: 12, alignItems: 'center', backgroundColor: COLORS.white },
  socialText: { fontSize: 14, fontWeight: '600', color: COLORS.text2 },
});
