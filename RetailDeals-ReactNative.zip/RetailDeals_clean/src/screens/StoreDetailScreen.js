import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Linking } from 'react-native';
import { COLORS, STORES } from '../data/data';
import { useApp } from '../data/AppContext';
import DealCard from '../components/DealCard';
import DealModal from '../components/DealModal';

export default function StoreDetailScreen({ route, navigation }) {
  const { storeId } = route.params;
  const { countryDeals } = useApp();
  const [typeFilter, setTypeFilter] = useState('All');
  const [modalDeal, setModalDeal] = useState(null);
  const store = STORES.find(s => s.id === storeId);
  if (!store) return null;

  let deals = countryDeals().filter(d => d.sid === storeId);
  if (typeFilter === 'Deals')   deals = deals.filter(d => d.type === 'deal');
  if (typeFilter === 'Coupons') deals = deals.filter(d => d.type === 'coupon');

  return (
    <ScrollView style={styles.wrap} showsVerticalScrollIndicator={false}>
      <View style={styles.hero}>
        <Text style={styles.storeLogo}>{store.logo}</Text>
        <View style={{ flex: 1 }}>
          <Text style={styles.storeName}>{store.name}</Text>
          <Text style={styles.storeDesc}>{store.desc}</Text>
          <View style={styles.statsRow}>
            {[{ n: store.deals, l: 'Deals' }, { n: store.rating + '⭐', l: 'Rating' }, { n: store.cat, l: 'Category' }].map(s => (
              <View key={s.l} style={styles.stat}>
                <Text style={styles.statN}>{s.n}</Text>
                <Text style={styles.statL}>{s.l}</Text>
              </View>
            ))}
          </View>
          <TouchableOpacity style={styles.visitBtn} onPress={() => Linking.openURL(store.href)}>
            <Text style={styles.visitText}>🌐 Visit {store.name} →</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>🔥 {store.name} Deals</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterRow}>
          {['All', 'Deals', 'Coupons'].map(f => (
            <TouchableOpacity key={f} style={[styles.pill, typeFilter === f && styles.pillActive]} onPress={() => setTypeFilter(f)}>
              <Text style={[styles.pillText, typeFilter === f && styles.pillTextActive]}>
                {f === 'All' ? '🔥 All' : f === 'Deals' ? '⚡ Deals' : '🎟️ Coupons'}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        {deals.length === 0
          ? <Text style={styles.empty}>No {typeFilter !== 'All' ? typeFilter.toLowerCase() + ' ' : ''}deals for this store in your country.</Text>
          : deals.map(d => <DealCard key={d.id} deal={d} onPressCoupon={setModalDeal} onPressDeal={setModalDeal} />)
        }
      </View>
      <DealModal deal={modalDeal} visible={!!modalDeal} onClose={() => setModalDeal(null)} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  hero: { backgroundColor: COLORS.white, padding: 20, flexDirection: 'row', gap: 14, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  storeLogo: { fontSize: 52, width: 72, height: 72, textAlign: 'center', lineHeight: 72, backgroundColor: COLORS.surface2, borderRadius: 16 },
  storeName: { fontSize: 20, fontWeight: '800', color: COLORS.text, marginBottom: 4 },
  storeDesc: { fontSize: 13, color: COLORS.text2, marginBottom: 10, lineHeight: 18 },
  statsRow: { flexDirection: 'row', gap: 16, marginBottom: 12 },
  stat: {},
  statN: { fontSize: 14, fontWeight: '700', color: COLORS.orange },
  statL: { fontSize: 10, color: COLORS.muted, textTransform: 'uppercase' },
  visitBtn: { backgroundColor: COLORS.blue, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 9, alignSelf: 'flex-start' },
  visitText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  section: { padding: 16 },
  sectionTitle: { fontSize: 18, fontWeight: '800', color: COLORS.text, marginBottom: 12 },
  filterRow: { gap: 8, paddingBottom: 14 },
  pill: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1.5, borderColor: COLORS.border, backgroundColor: COLORS.white },
  pillActive: { backgroundColor: COLORS.orange, borderColor: COLORS.orange },
  pillText: { fontSize: 13, fontWeight: '500', color: COLORS.text2 },
  pillTextActive: { color: '#fff', fontWeight: '700' },
  empty: { textAlign: 'center', color: COLORS.muted, padding: 24, fontSize: 14 },
});
