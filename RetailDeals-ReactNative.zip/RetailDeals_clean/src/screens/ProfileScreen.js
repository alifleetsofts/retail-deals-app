import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { COLORS, DEALS, COUNTRIES } from '../data/data';
import { useApp } from '../data/AppContext';
import DealCard from '../components/DealCard';
import DealModal from '../components/DealModal';

export default function ProfileScreen({ onLogout }) {
  const { user, country, setCountry, savedDeals, logout } = useApp();
  const [tab, setTab] = useState('saved');
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [whatsapp, setWhatsapp] = useState('');
  const [selectedCountry, setSelectedCountry] = useState(country);
  const [modalDeal, setModalDeal] = useState(null);

  const saved = DEALS.filter(d => savedDeals.includes(d.id));
  const history = DEALS.slice(1, 4);

  const handleSave = () => {
    setCountry(selectedCountry);
    alert('Settings saved!' + (whatsapp ? '\n📲 WhatsApp alerts enabled for ' + whatsapp : ''));
  };

  const handleLogout = () => { logout(); onLogout(); };
  const c = COUNTRIES.find(x => x.code === country);

  return (
    <ScrollView style={styles.wrap} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
      {/* HERO */}
      <LinearGradient colors={['#FFF8F3', '#F0EDE5']} style={styles.hero}>
        <View style={styles.avatarWrap}>
          <LinearGradient colors={['#F26522', '#F2786E']} style={styles.avatar}>
            <Text style={styles.avatarText}>{user?.init || 'U'}</Text>
          </LinearGradient>
        </View>
        <Text style={styles.userName}>{user?.name || 'User'}</Text>
        <Text style={styles.userEmail}>{user?.email}{c ? ' · ' + c.flag + ' ' + c.name : ''}</Text>
        <View style={styles.statsRow}>
          {[{ n: '$1,240', l: 'Saved' }, { n: savedDeals.length, l: 'Saved Deals' }, { n: '12', l: 'Reviews' }].map(s => (
            <View key={s.l} style={styles.stat}>
              <Text style={styles.statN}>{s.n}</Text>
              <Text style={styles.statL}>{s.l}</Text>
            </View>
          ))}
        </View>
      </LinearGradient>

      {/* TABS */}
      <View style={styles.tabs}>
        {[['saved', '💾 Saved'], ['history', '🕑 History'], ['settings', '⚙️ Settings']].map(([key, label]) => (
          <TouchableOpacity key={key} style={[styles.tab, tab === key && styles.tabActive]} onPress={() => setTab(key)}>
            <Text style={[styles.tabText, tab === key && styles.tabTextActive]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.content}>
        {tab === 'saved' && (
          saved.length === 0
            ? <Text style={styles.empty}>No saved deals yet. Tap 🔖 on any deal to save it.</Text>
            : saved.map(d => <DealCard key={d.id} deal={d} onPressCoupon={setModalDeal} onPressDeal={setModalDeal} />)
        )}
        {tab === 'history' && history.map(d => (
          <View key={d.id} style={styles.histItem}>
            <Text style={styles.histEmoji}>{d.emoji}</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.histTitle} numberOfLines={1}>{d.title}</Text>
              <Text style={styles.histMeta}>{d.store} · Used 2 days ago</Text>
            </View>
            <Text style={styles.histDisc}>{d.disc}</Text>
          </View>
        ))}
        {tab === 'settings' && (
          <View>
            <Text style={styles.label}>Full Name</Text>
            <TextInput style={styles.input} value={name} onChangeText={setName} />
            <Text style={styles.label}>Email Address</Text>
            <TextInput style={styles.input} value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
            <Text style={styles.label}>Country</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.countryRow}>
              {COUNTRIES.map(ct => (
                <TouchableOpacity key={ct.code} style={[styles.countryChip, selectedCountry === ct.code && styles.countryChipSel]} onPress={() => setSelectedCountry(ct.code)}>
                  <Text style={styles.countryFlag}>{ct.flag}</Text>
                  <Text style={[styles.countryCode, selectedCountry === ct.code && { color: COLORS.orange }]}>{ct.code}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            {/* WHATSAPP */}
            <View style={styles.waSection}>
              <View style={styles.waLabelRow}>
                <Text style={styles.label}>📱 WhatsApp Number</Text>
                <View style={styles.optionalChip}><Text style={styles.optionalText}>Optional</Text></View>
              </View>
              <View style={styles.waInputRow}>
                <View style={styles.waPrefix}><Text style={styles.waPrefixText}>📲</Text></View>
                <TextInput
                  style={styles.waInput}
                  placeholder="+1 555 000 0000"
                  placeholderTextColor={COLORS.muted2}
                  keyboardType="phone-pad"
                  value={whatsapp}
                  onChangeText={setWhatsapp}
                />
              </View>
              <Text style={styles.waHint}>✅ Get instant deal alerts & coupon notifications on WhatsApp</Text>
            </View>
            <View style={styles.infoBox}>
              <Text style={styles.infoText}>ℹ️ Your WhatsApp number will only be used to send deal alerts. We will never share your number.</Text>
            </View>
            <TouchableOpacity style={styles.saveBtn} onPress={handleSave}>
              <Text style={styles.saveBtnText}>Save Changes</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
              <Text style={styles.logoutBtnText}>Sign Out</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
      <DealModal deal={modalDeal} visible={!!modalDeal} onClose={() => setModalDeal(null)} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  hero: { padding: 24, paddingTop: 32, alignItems: 'center', borderBottomWidth: 1, borderBottomColor: COLORS.border },
  avatarWrap: { marginBottom: 10 },
  avatar: { width: 72, height: 72, borderRadius: 36, alignItems: 'center', justifyContent: 'center', shadowColor: COLORS.orange, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.28, shadowRadius: 8, elevation: 4 },
  avatarText: { color: '#fff', fontSize: 28, fontWeight: '800' },
  userName: { fontSize: 20, fontWeight: '800', color: COLORS.text, marginBottom: 4 },
  userEmail: { fontSize: 13, color: COLORS.text2, marginBottom: 14 },
  statsRow: { flexDirection: 'row', gap: 28 },
  stat: { alignItems: 'center' },
  statN: { fontSize: 18, fontWeight: '800', color: COLORS.orange },
  statL: { fontSize: 10, color: COLORS.muted, textTransform: 'uppercase', letterSpacing: 0.4, marginTop: 2 },
  tabs: { flexDirection: 'row', backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  tab: { flex: 1, paddingVertical: 13, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabActive: { borderBottomColor: COLORS.orange },
  tabText: { fontSize: 12, fontWeight: '600', color: COLORS.muted },
  tabTextActive: { color: COLORS.orange },
  content: { padding: 16, paddingBottom: 40 },
  empty: { textAlign: 'center', color: COLORS.muted, padding: 32, fontSize: 14, lineHeight: 20 },
  histItem: { backgroundColor: COLORS.white, borderRadius: 12, padding: 14, marginBottom: 10, flexDirection: 'row', alignItems: 'center', gap: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  histEmoji: { fontSize: 28, width: 40, textAlign: 'center' },
  histTitle: { fontSize: 13, fontWeight: '700', color: COLORS.text },
  histMeta: { fontSize: 11, color: COLORS.muted, marginTop: 2 },
  histDisc: { fontSize: 15, fontWeight: '800', color: COLORS.orange },
  label: { fontSize: 11, fontWeight: '700', color: COLORS.muted, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6, marginTop: 16 },
  input: { backgroundColor: COLORS.white, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, color: COLORS.text },
  countryRow: { gap: 8, paddingVertical: 4 },
  countryChip: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10, borderWidth: 1.5, borderColor: COLORS.border, backgroundColor: COLORS.white },
  countryChipSel: { borderColor: COLORS.orange, backgroundColor: COLORS.orangeLt },
  countryFlag: { fontSize: 18 },
  countryCode: { fontSize: 12, fontWeight: '700', color: COLORS.text2 },
  waSection: { marginTop: 6 },
  waLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 6, marginTop: 16 },
  optionalChip: { backgroundColor: COLORS.greenLt, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 20 },
  optionalText: { fontSize: 10, fontWeight: '700', color: COLORS.green },
  waInputRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.white, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 10, overflow: 'hidden' },
  waPrefix: { paddingHorizontal: 12, paddingVertical: 12, borderRightWidth: 1, borderRightColor: COLORS.border, backgroundColor: COLORS.surface2 },
  waPrefixText: { fontSize: 16 },
  waInput: { flex: 1, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, color: COLORS.text },
  waHint: { fontSize: 12, color: COLORS.green, fontWeight: '600', marginTop: 6 },
  infoBox: { backgroundColor: COLORS.blueLt, borderWidth: 1, borderColor: 'rgba(59,125,216,0.2)', borderRadius: 10, padding: 12, marginTop: 14 },
  infoText: { fontSize: 12, color: '#2B66BF', lineHeight: 17 },
  saveBtn: { backgroundColor: COLORS.orange, borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginTop: 20, shadowColor: COLORS.orange, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.28, shadowRadius: 8, elevation: 4 },
  saveBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  logoutBtn: { borderWidth: 1.5, borderColor: COLORS.coral, borderRadius: 12, paddingVertical: 13, alignItems: 'center', marginTop: 10 },
  logoutBtnText: { color: COLORS.coral, fontSize: 15, fontWeight: '700' },
});
