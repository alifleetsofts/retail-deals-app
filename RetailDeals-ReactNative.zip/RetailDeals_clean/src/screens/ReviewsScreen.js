import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet } from 'react-native';
import { COLORS, DEALS, REVIEWS } from '../data/data';
import { useApp } from '../data/AppContext';

export default function ReviewsScreen() {
  const { user, reviews, addReview } = useApp();
  const allReviews = [...reviews, ...REVIEWS];
  const [sort, setSort] = useState('recent');
  const [writeRating, setWriteRating] = useState(0);
  const [text, setText] = useState('');
  const [dealId, setDealId] = useState(1);
  const [showDealPicker, setShowDealPicker] = useState(false);

  let sorted = [...allReviews];
  if (sort === 'top') sorted.sort((a, b) => b.rating - a.rating);
  else if (sort === 'helpful') sorted.sort((a, b) => b.helpful - a.helpful);
  else sorted.sort((a, b) => b.id - a.id);

  const submit = () => {
    if (!text || !writeRating) return;
    const deal = DEALS.find(d => d.id === dealId);
    addReview({ id: Date.now(), user: user?.name || 'You', av: (user?.name || 'Y')[0], rating: writeRating, deal: deal ? deal.store + ' – ' + deal.title.substring(0, 35) + '…' : '', text, date: 'Just now', helpful: 0, notHelpful: 0 });
    setText(''); setWriteRating(0);
  };

  const selectedDeal = DEALS.find(d => d.id === dealId);

  return (
    <ScrollView style={styles.wrap} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
      <View style={styles.header}>
        <Text style={styles.h1}>Community Reviews</Text>
        <Text style={styles.sub}>Rate deals, share tips, help others save more</Text>
      </View>

      {/* WRITE REVIEW */}
      <View style={styles.writeBox}>
        <Text style={styles.writeTitle}>✍️ Write a Review</Text>
        <Text style={styles.label}>Select Deal</Text>
        <TouchableOpacity style={styles.dealPicker} onPress={() => setShowDealPicker(!showDealPicker)}>
          <Text style={styles.dealPickerText} numberOfLines={1}>{selectedDeal ? selectedDeal.store + ' – ' + selectedDeal.title : 'Select a deal…'}</Text>
          <Text>{showDealPicker ? '▲' : '▼'}</Text>
        </TouchableOpacity>
        {showDealPicker && (
          <View style={styles.dealList}>
            {DEALS.slice(0, 8).map(d => (
              <TouchableOpacity key={d.id} style={[styles.dealOption, dealId === d.id && styles.dealOptionSel]} onPress={() => { setDealId(d.id); setShowDealPicker(false); }}>
                <Text style={styles.dealOptionText} numberOfLines={1}>{d.emoji} {d.store} – {d.title}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
        <Text style={styles.label}>Your Rating</Text>
        <View style={styles.starsRow}>
          {[1,2,3,4,5].map(n => (
            <TouchableOpacity key={n} onPress={() => setWriteRating(n)}>
              <Text style={[styles.writeStar, n <= writeRating && styles.writeStarOn]}>★</Text>
            </TouchableOpacity>
          ))}
        </View>
        <TextInput style={styles.textarea} placeholder="Share your experience…" placeholderTextColor={COLORS.muted2} multiline value={text} onChangeText={setText} />
        <TouchableOpacity style={styles.postBtn} onPress={submit}>
          <Text style={styles.postBtnText}>Post Review →</Text>
        </TouchableOpacity>
      </View>

      {/* SORT */}
      <View style={styles.sortRow}>
        {[['recent','Most Recent'],['top','Top Rated'],['helpful','Most Helpful']].map(([val, label]) => (
          <TouchableOpacity key={val} style={[styles.sortBtn, sort === val && styles.sortBtnActive]} onPress={() => setSort(val)}>
            <Text style={[styles.sortBtnText, sort === val && styles.sortBtnTextActive]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.list}>
        {sorted.map(r => <ReviewCard key={r.id} r={r} />)}
      </View>
    </ScrollView>
  );
}

function ReviewCard({ r }) {
  const [helpful, setHelpful] = useState(r.helpful);
  return (
    <View style={styles.reviewCard}>
      <View style={styles.rvHead}>
        <View style={styles.rvUser}>
          <View style={styles.rvAv}><Text style={styles.rvAvText}>{r.av}</Text></View>
          <View><Text style={styles.rvName}>{r.user}</Text><Text style={styles.rvDate}>{r.date}</Text></View>
        </View>
        <View style={styles.rvStars}>{[1,2,3,4,5].map(n => <Text key={n} style={[styles.rvStar, n <= r.rating && styles.rvStarOn]}>★</Text>)}</View>
      </View>
      <Text style={styles.rvText}>{r.text}</Text>
      <View style={styles.rvDealRef}><Text style={styles.rvDealText}>🛍️ {r.deal}</Text></View>
      <View style={styles.rvVotes}>
        <TouchableOpacity style={styles.voteBtn} onPress={() => setHelpful(h => h + 1)}>
          <Text style={styles.voteBtnText}>👍 Helpful ({helpful})</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  header: { padding: 20, paddingTop: 24 },
  h1: { fontSize: 24, fontWeight: '800', color: COLORS.text, marginBottom: 4 },
  sub: { fontSize: 13, color: COLORS.text2 },
  writeBox: { backgroundColor: COLORS.white, margin: 16, borderRadius: 16, padding: 18, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  writeTitle: { fontSize: 16, fontWeight: '800', color: COLORS.text, marginBottom: 14 },
  label: { fontSize: 11, fontWeight: '700', color: COLORS.muted, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6, marginTop: 12 },
  dealPicker: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: COLORS.surface2, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 11 },
  dealPickerText: { flex: 1, fontSize: 13, color: COLORS.text2 },
  dealList: { backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.border, borderRadius: 10, marginTop: 4, overflow: 'hidden' },
  dealOption: { paddingHorizontal: 14, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  dealOptionSel: { backgroundColor: COLORS.orangeLt },
  dealOptionText: { fontSize: 12, color: COLORS.text2 },
  starsRow: { flexDirection: 'row', gap: 4 },
  writeStar: { fontSize: 28, color: COLORS.border },
  writeStarOn: { color: COLORS.orange },
  textarea: { backgroundColor: COLORS.surface2, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 10, padding: 12, fontSize: 14, color: COLORS.text, minHeight: 80, marginTop: 12, textAlignVertical: 'top' },
  postBtn: { backgroundColor: COLORS.orange, borderRadius: 10, paddingVertical: 13, alignItems: 'center', marginTop: 14 },
  postBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  sortRow: { flexDirection: 'row', gap: 8, paddingHorizontal: 16, paddingBottom: 12, flexWrap: 'wrap' },
  sortBtn: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, borderWidth: 1.5, borderColor: COLORS.border, backgroundColor: COLORS.white },
  sortBtnActive: { backgroundColor: COLORS.orange, borderColor: COLORS.orange },
  sortBtnText: { fontSize: 12, fontWeight: '600', color: COLORS.text2 },
  sortBtnTextActive: { color: '#fff' },
  list: { paddingHorizontal: 16, paddingBottom: 30 },
  reviewCard: { backgroundColor: COLORS.white, borderRadius: 14, padding: 16, marginBottom: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  rvHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 },
  rvUser: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  rvAv: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.orangeLt, alignItems: 'center', justifyContent: 'center' },
  rvAvText: { fontSize: 16, fontWeight: '700', color: COLORS.orange },
  rvName: { fontSize: 14, fontWeight: '700', color: COLORS.text },
  rvDate: { fontSize: 11, color: COLORS.muted },
  rvStars: { flexDirection: 'row', gap: 2 },
  rvStar: { fontSize: 13, color: COLORS.border },
  rvStarOn: { color: COLORS.orange },
  rvText: { fontSize: 13, color: COLORS.text2, lineHeight: 19, marginBottom: 10 },
  rvDealRef: { backgroundColor: COLORS.surface2, borderRadius: 8, padding: 8, marginBottom: 10 },
  rvDealText: { fontSize: 12, color: COLORS.text2 },
  rvVotes: { flexDirection: 'row', gap: 8 },
  voteBtn: { borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 20, paddingHorizontal: 12, paddingVertical: 5 },
  voteBtnText: { fontSize: 12, fontWeight: '600', color: COLORS.text2 },
});
