import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORS, BLOG_POSTS } from '../data/data';

export default function BlogScreen() {
  const [cat, setCat] = useState('All');
  const allCats = ['All', ...new Set(BLOG_POSTS.map(p => p.cat))];
  const posts = cat === 'All' ? BLOG_POSTS : BLOG_POSTS.filter(p => p.cat === cat);

  return (
    <ScrollView style={styles.wrap} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.h1}>📰 RetailDeals Blog</Text>
        <Text style={styles.sub}>Saving tips & deal guides — latest posts first</Text>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.catRow}>
        {allCats.map(c => (
          <TouchableOpacity key={c} style={[styles.pill, cat === c && styles.pillActive]} onPress={() => setCat(c)}>
            <Text style={[styles.pillText, cat === c && styles.pillTextActive]}>{c}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <View style={styles.list}>
        {posts.map(p => (
          <View key={p.id} style={styles.card}>
            <View style={styles.cardImg}>
              <View style={styles.cardImgBg} />
              <Text style={styles.cardEmoji}>{p.emoji}</Text>
              <View style={styles.catBadge}>
                <Text style={styles.catBadgeText}>{p.cat}</Text>
              </View>
            </View>
            <View style={styles.cardBody}>
              <View style={styles.metaRow}>
                <Text style={styles.meta}>{p.date}</Text>
                <Text style={styles.metaDot}>·</Text>
                <Text style={styles.meta}>{p.read} read</Text>
                <Text style={styles.metaDot}>·</Text>
                <Text style={styles.meta}>{p.author}</Text>
                {p.isNew && <View style={styles.newChip}><Text style={styles.newChipText}>NEW</Text></View>}
              </View>
              <Text style={styles.cardTitle}>{p.title}</Text>
              <Text style={styles.cardExcerpt} numberOfLines={3}>{p.excerpt}</Text>
              <Text style={styles.readMore}>Read more →</Text>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  header: { padding: 20, paddingTop: 24 },
  h1: { fontSize: 24, fontWeight: '800', color: COLORS.text, marginBottom: 4 },
  sub: { fontSize: 13, color: COLORS.text2 },
  catRow: { paddingHorizontal: 16, paddingBottom: 14, gap: 8 },
  pill: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1.5, borderColor: COLORS.border, backgroundColor: COLORS.white },
  pillActive: { backgroundColor: COLORS.orange, borderColor: COLORS.orange },
  pillText: { fontSize: 13, fontWeight: '500', color: COLORS.text2 },
  pillTextActive: { color: '#fff', fontWeight: '700' },
  list: { paddingHorizontal: 16, paddingBottom: 30 },
  card: { backgroundColor: COLORS.white, borderRadius: 16, marginBottom: 16, overflow: 'hidden', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 3 },
  cardImg: { height: 140, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  cardImgBg: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: COLORS.orangeLt },
  cardEmoji: { fontSize: 52, zIndex: 1 },
  catBadge: { position: 'absolute', bottom: 10, left: 12, backgroundColor: COLORS.orange, paddingHorizontal: 10, paddingVertical: 3, borderRadius: 20 },
  catBadgeText: { color: '#fff', fontSize: 10, fontWeight: '700' },
  cardBody: { padding: 16 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginBottom: 8, flexWrap: 'wrap' },
  meta: { fontSize: 11, color: COLORS.muted },
  metaDot: { fontSize: 11, color: COLORS.muted2 },
  newChip: { backgroundColor: COLORS.greenLt, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 20 },
  newChipText: { fontSize: 10, fontWeight: '700', color: COLORS.green },
  cardTitle: { fontSize: 15, fontWeight: '700', color: COLORS.text, marginBottom: 6, lineHeight: 21 },
  cardExcerpt: { fontSize: 13, color: COLORS.text2, lineHeight: 18, marginBottom: 10 },
  readMore: { fontSize: 13, color: COLORS.orange, fontWeight: '600' },
});
