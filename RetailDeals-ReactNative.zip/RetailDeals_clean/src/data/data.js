export const COLORS = {
  bg:        '#F7F6F2',
  bg2:       '#EFEDE8',
  white:     '#FFFFFF',
  surface:   '#FFFFFF',
  surface2:  '#F3F2EE',
  border:    '#E4E2DC',
  orange:    '#F26522',
  orangeLt:  '#FEF0E8',
  orangeDk:  '#D4521A',
  green:     '#2EB87E',
  greenLt:   '#E6F8F1',
  greenDk:   '#1E9A65',
  blue:      '#3B7DD8',
  blueLt:    '#EBF2FC',
  coral:     '#F2786E',
  coralLt:   '#FEF0EF',
  text:      '#1A1A24',
  text2:     '#4A4A5A',
  muted:     '#8A8A9A',
  muted2:    '#AEAEBA',
};

export const COUNTRIES = [
  { code:'US', flag:'🇺🇸', name:'United States', deals:1240, stores:280 },
  { code:'UK', flag:'🇬🇧', name:'United Kingdom', deals:870,  stores:190 },
  { code:'CA', flag:'🇨🇦', name:'Canada',         deals:620,  stores:140 },
  { code:'AU', flag:'🇦🇺', name:'Australia',      deals:540,  stores:120 },
  { code:'PK', flag:'🇵🇰', name:'Pakistan',       deals:390,  stores:80  },
  { code:'IN', flag:'🇮🇳', name:'India',          deals:940,  stores:200 },
  { code:'AE', flag:'🇦🇪', name:'UAE',            deals:480,  stores:110 },
];

export const CATEGORIES = [
  { name:'Electronics', icon:'💻', bg:'#EBF2FC', tags:['Laptops','Phones','TVs','Gaming'] },
  { name:'Fashion',     icon:'👗', bg:'#FEF0E8', tags:['Clothes','Shoes','Bags'] },
  { name:'Travel',      icon:'✈️', bg:'#E6F8F1', tags:['Hotels','Flights','Packages'] },
  { name:'Food',        icon:'🍔', bg:'#FFF8E6', tags:['Delivery','Restaurants'] },
  { name:'Beauty',      icon:'💄', bg:'#FEF0EF', tags:['Skincare','Makeup','Hair'] },
  { name:'Sports',      icon:'⚽', bg:'#E6F8F1', tags:['Gym','Outdoor','Yoga'] },
  { name:'Home',        icon:'🏠', bg:'#F0EDE5', tags:['Furniture','Decor','Kitchen'] },
  { name:'Grocery',     icon:'🛒', bg:'#F3F2EE', tags:['Supermarket','Fresh','Organic'] },
];

export const STORES = [
  { id:1,  name:'Amazon',      logo:'📦', cat:'Electronics', desc:"World's largest online retailer.",        deals:120, rating:4.8, countries:['US','UK','CA','AU','IN','AE'], href:'https://amazon.com' },
  { id:2,  name:'Nike',        logo:'👟', cat:'Fashion',     desc:'Athletic shoes and apparel.',             deals:45,  rating:4.6, countries:['US','UK','CA','AU','PK','IN','AE'], href:'https://nike.com' },
  { id:3,  name:'Booking.com', logo:'🏨', cat:'Travel',      desc:'Hotels & travel deals worldwide.',        deals:88,  rating:4.7, countries:['US','UK','CA','AU','PK','IN','AE'], href:'https://booking.com' },
  { id:4,  name:'Uber Eats',   logo:'🍔', cat:'Food',        desc:'Food delivery from local restaurants.',   deals:32,  rating:4.4, countries:['US','UK','CA','AU','IN'], href:'https://ubereats.com' },
  { id:5,  name:'Daraz',       logo:'🛒', cat:'Electronics', desc:'Top marketplace in South Asia.',          deals:67,  rating:4.3, countries:['PK'], href:'https://daraz.pk' },
  { id:6,  name:'Noon',        logo:'☀️', cat:'Electronics', desc:'Premier e-commerce in Middle East.',      deals:54,  rating:4.5, countries:['AE'], href:'https://noon.com' },
  { id:7,  name:'ASOS',        logo:'👗', cat:'Fashion',     desc:'Online fashion for young adults.',        deals:62,  rating:4.6, countries:['UK','AU','US'], href:'https://asos.com' },
  { id:8,  name:'Flipkart',    logo:'🛍️', cat:'Electronics', desc:"India's leading e-commerce platform.",   deals:98,  rating:4.5, countries:['IN'], href:'https://flipkart.com' },
  { id:9,  name:'Expedia',     logo:'✈️', cat:'Travel',      desc:'Flights, hotels & vacation packages.',    deals:77,  rating:4.5, countries:['US','UK','CA','AU'], href:'https://expedia.com' },
  { id:10, name:'Sephora',     logo:'💄', cat:'Beauty',      desc:'Luxury beauty & skincare products.',      deals:38,  rating:4.7, countries:['US','UK','CA','AU'], href:'https://sephora.com' },
  { id:11, name:'Walmart',     logo:'🏬', cat:'Grocery',     desc:'Everyday low prices on everything.',      deals:150, rating:4.4, countries:['US','CA'], href:'https://walmart.com' },
  { id:12, name:'Zomato',      logo:'🍕', cat:'Food',        desc:'Food delivery & restaurant discovery.',   deals:29,  rating:4.3, countries:['IN'], href:'https://zomato.com' },
];

export const DEALS = [
  { id:1,  store:'Amazon',      sid:1,  cat:'Electronics', title:'Up to 40% off Laptops',               desc:'Huge savings on Apple, Dell, HP and more top brands.',          type:'deal',   disc:'40% OFF',   code:null,          exp:'Mar 31',      rating:4.8, badge:'hot', emoji:'💻', countries:['US','UK','CA','AU','IN','AE'], href:'https://amazon.com/laptops' },
  { id:2,  store:'Nike',        sid:2,  cat:'Fashion',     title:'Extra 20% off Sale Items',            desc:'Apply code at checkout for extra savings on reduced prices.',   type:'coupon', disc:'20% OFF',   code:'SAVE20NIKE',  exp:'Apr 15',      rating:4.6, badge:'new', emoji:'👟', countries:['US','UK','CA','AU','PK','IN','AE'], href:'https://nike.com/sale' },
  { id:3,  store:'Booking.com', sid:3,  cat:'Travel',      title:'Genius: Up to 30% off Hotels',       desc:'Exclusive hotel discounts for Genius members in 2000+ places.', type:'deal',   disc:'30% OFF',   code:null,          exp:'Ongoing',     rating:4.7, badge:'',    emoji:'🏨', countries:['US','UK','CA','AU','PK','IN','AE'], href:'https://booking.com' },
  { id:4,  store:'Uber Eats',   sid:4,  cat:'Food',        title:'Free Delivery – First 3 Orders',     desc:'New users get zero delivery fees on first three orders.',        type:'coupon', disc:'FREE',      code:'EATFREE3',    exp:'Apr 30',      rating:4.5, badge:'new', emoji:'🍔', countries:['US','UK','CA','AU','IN'], href:'https://ubereats.com' },
  { id:5,  store:'Daraz',       sid:5,  cat:'Electronics', title:'Mega Sale – Up to 70% Off',          desc:"Pakistan's biggest online sale across all categories.",          type:'deal',   disc:'70% OFF',   code:null,          exp:'Nov 11',      rating:4.3, badge:'hot', emoji:'📱', countries:['PK'], href:'https://daraz.pk' },
  { id:6,  store:'ASOS',        sid:7,  cat:'Fashion',     title:'25% Off Everything This Weekend',    desc:'Site-wide discount — no minimum spend required.',               type:'coupon', disc:'25% OFF',   code:'ASOSWKND',    exp:'This Weekend',rating:4.6, badge:'hot', emoji:'👗', countries:['UK','AU','US'], href:'https://asos.com' },
  { id:7,  store:'Sephora',     sid:10, cat:'Beauty',      title:'Buy 2 Get 1 Free on Skincare',       desc:'Mix and match eligible skincare products.',                     type:'deal',   disc:'B2G1',      code:null,          exp:'Mar 25',      rating:4.7, badge:'',    emoji:'💄', countries:['US','UK','CA','AU'], href:'https://sephora.com' },
  { id:8,  store:'Amazon',      sid:1,  cat:'Electronics', title:'Echo Dot 5th Gen – Save $25',        desc:'Smart speaker with improved audio at a record low price.',      type:'deal',   disc:'$25 OFF',   code:null,          exp:'Mar 28',      rating:4.9, badge:'new', emoji:'🔈', countries:['US','UK','CA','AU'], href:'https://amazon.com/echo' },
  { id:9,  store:'Flipkart',    sid:8,  cat:'Electronics', title:'Big Billion Days – 80% Off',         desc:"India's biggest sale event with unbeatable discounts.",          type:'deal',   disc:'80% OFF',   code:null,          exp:'Apr 5',       rating:4.5, badge:'hot', emoji:'📺', countries:['IN'], href:'https://flipkart.com' },
  { id:10, store:'Noon',        sid:6,  cat:'Electronics', title:'Flash Sale: 15% Off Storewide',      desc:'Use the exclusive code for instant savings on all items.',      type:'coupon', disc:'15% OFF',   code:'NOON15AE',    exp:'Mar 22',      rating:4.4, badge:'new', emoji:'☀️', countries:['AE'], href:'https://noon.com' },
  { id:11, store:'Expedia',     sid:9,  cat:'Travel',      title:'$500 Off Flight + Hotel Bundles',    desc:'Bundle flights and hotel for maximum savings.',                 type:'deal',   disc:'$500 OFF',  code:null,          exp:'Apr 20',      rating:4.5, badge:'',    emoji:'✈️', countries:['US','UK','CA','AU'], href:'https://expedia.com' },
  { id:12, store:'Nike',        sid:2,  cat:'Sports',      title:'Free Shipping on Orders Over $50',   desc:'No code needed — applied automatically at checkout.',           type:'deal',   disc:'FREE SHIP', code:null,          exp:'Ongoing',     rating:4.4, badge:'',    emoji:'🏃', countries:['US','UK','CA','AU','PK','IN','AE'], href:'https://nike.com' },
  { id:13, store:'Walmart',     sid:11, cat:'Grocery',     title:'$10 Off First Grocery Order',        desc:'New customers save on fresh groceries delivered to your door.', type:'coupon', disc:'$10 OFF',   code:'WALMARTFRESH',exp:'Apr 30',      rating:4.3, badge:'new', emoji:'🛒', countries:['US','CA'], href:'https://walmart.com' },
];

export const BLOG_POSTS = [
  { id:1, title:'10 Best Amazon Deals This Week',         cat:'Deals Roundup', emoji:'📦', date:'Mar 19, 2025', author:'Sarah K.', read:'4 min', excerpt:'We scoured Amazon so you don\'t have to. These deals offer serious value across electronics, home and fashion.', isNew:true },
  { id:2, title:'How to Stack Coupons for Max Savings',   cat:'Money Tips',    emoji:'💰', date:'Mar 17, 2025', author:'Mike R.',  read:'6 min', excerpt:'Stacking coupons is an art. Learn to combine store coupons, cashback and promo codes on every order.', isNew:true },
  { id:3, title:'Best Travel Deals for Summer 2025',      cat:'Travel',        emoji:'✈️', date:'Mar 15, 2025', author:'Leila H.', read:'5 min', excerpt:'Summer flights and hotels are filling up fast. The best deals for European and Asian destinations.', isNew:false },
  { id:4, title:'Nike vs Adidas: Which Has Better Sales?',cat:'Fashion',       emoji:'👟', date:'Mar 12, 2025', author:'Tom B.',   read:'3 min', excerpt:'We compared a full year of promotions to find which brand offers more value and bigger discounts.', isNew:false },
  { id:5, title:"Pakistan's Best Shopping Apps 2025",     cat:'Country Guide', emoji:'🇵🇰', date:'Mar 10, 2025', author:'Ali A.',   read:'7 min', excerpt:'From Daraz to Goto, we review all major Pakistani e-commerce platforms comparing prices and coupons.', isNew:false },
  { id:6, title:'Sephora Sale Survival Guide',            cat:'Beauty',        emoji:'💄', date:'Mar 8,  2025', author:'Emma P.', read:'5 min', excerpt:"Sephora's annual sale can be overwhelming. Here's what to buy, skip, and which coupons to stack.", isNew:false },
];

export const NOTIFICATIONS = [
  { id:1, icon:'🔥', title:'New Deal Alert!',       text:'Amazon added 150 new deals — up to 50% off electronics!', time:'2 min ago',  unread:true  },
  { id:2, icon:'🎟️', title:'Coupon Expiring Soon',  text:'Your saved Nike coupon SAVE20NIKE expires in 24 hours.',  time:'1 hour ago', unread:true  },
  { id:3, icon:'⭐', title:'Deal of the Day',        text:'Booking.com: 40% off selected hotels — today only!',      time:'3 hours ago',unread:true  },
  { id:4, icon:'🛍️', title:'New Store Added',       text:'H&M joined RetailDeals with 20 exclusive coupons.',       time:'Yesterday',  unread:false },
  { id:5, icon:'💰', title:'Cashback Available',     text:'Earn 5% cashback on all Sephora purchases this week.',   time:'2 days ago', unread:false },
];

export const REVIEWS = [
  { id:1, user:'Alex M.',   av:'A', rating:5, deal:'Amazon – 40% off Laptops',       text:'Worked perfectly! Saved over $200 on a Dell laptop. The discount applied automatically at checkout.',      date:'Mar 18, 2025', helpful:42, notHelpful:2 },
  { id:2, user:'Priya S.',  av:'P', rating:4, deal:'Nike – SAVE20NIKE',               text:'The coupon worked but took a couple of tries. Make sure you have at least one sale item. Great savings!', date:'Mar 16, 2025', helpful:28, notHelpful:5 },
  { id:3, user:'James R.',  av:'J', rating:5, deal:'Booking.com – 30% off Hotels',    text:'Booked a hotel in London and saved £85. The Genius deal was legitimate and applied instantly.',           date:'Mar 14, 2025', helpful:61, notHelpful:1 },
  { id:4, user:'Fatima K.', av:'F', rating:3, deal:'Uber Eats – EATFREE3',            text:'First two orders were free but the third charged me. Customer support sorted it eventually.',              date:'Mar 12, 2025', helpful:15, notHelpful:8 },
  { id:5, user:'Chris T.',  av:'C', rating:5, deal:'ASOS – ASOSWKND',                 text:'Grabbed three shirts and a jacket with 25% off. Total came to £67 instead of £89. Amazing!',             date:'Mar 10, 2025', helpful:33, notHelpful:0 },
];
