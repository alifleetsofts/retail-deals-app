import React, { createContext, useContext, useState } from 'react';
import { NOTIFICATIONS, DEALS } from './data';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [user, setUser]             = useState(null);
  const [country, setCountry]       = useState('US');
  const [savedDeals, setSavedDeals] = useState([]);
  const [notifs, setNotifs]         = useState(NOTIFICATIONS);
  const [reviews, setReviews]       = useState([]);

  const login = (userData) => setUser(userData);
  const logout = () => { setUser(null); setSavedDeals([]); };

  const toggleSave = (dealId) => {
    setSavedDeals(prev =>
      prev.includes(dealId) ? prev.filter(x => x !== dealId) : [...prev, dealId]
    );
  };

  const markAllRead = () => setNotifs(prev => prev.map(n => ({ ...n, unread: false })));
  const markRead = (id) => setNotifs(prev => prev.map(n => n.id === id ? { ...n, unread: false } : n));

  const addReview = (review) => setReviews(prev => [review, ...prev]);

  const countryDeals = () => DEALS.filter(d => d.countries.includes(country));
  const unreadCount  = notifs.filter(n => n.unread).length;

  return (
    <AppContext.Provider value={{
      user, login, logout,
      country, setCountry,
      savedDeals, toggleSave,
      notifs, markAllRead, markRead, unreadCount,
      reviews, addReview,
      countryDeals,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
